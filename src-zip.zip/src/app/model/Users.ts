export class User {
    name:string;
    profile:string;
    bio:string;
    interests:string;
    role:string;
    id?:string;
}