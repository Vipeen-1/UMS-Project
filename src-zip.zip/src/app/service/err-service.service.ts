import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ErrServiceService {
  handleError(err: any): any {
    throw new Error('Method not implemented.');
  }

  constructor() { }
}
